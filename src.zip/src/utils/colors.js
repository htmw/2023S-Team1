export default colors  = {
    onBoarding:'#98D38F',
    appBackground:"#FFFFFF",
    appHeader:'#DFAE26',
    bottomTabs:'#00FFFF',
    alertScreenHeader:'#0E0E6',
    alertScreenBackground:'#AFEEEE',
    black:'#000000',
    white:'#ffffff'

}